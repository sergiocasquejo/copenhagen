<a name="1.3.9"></a>

# 1.3.8 (28.09.2016)
- Usr proper bower dependency for jquery easing.

<a name="1.3.8"></a>

# 1.3.8 (28.04.2016)
- Added minified file

<a name="1.3.7"></a>

# 1.3.7 (14.01.2016)
- Fixed JS error related to filter attribute.

<a name="1.3.6"></a>

# 1.3.6 (25.06.2015)

- Adds support for jQuery v1.9.0

<a name="1.3.5"></a>

# 1.3.5 (20.06.2015)
- build v1.3.5
- Initial commit, mostly based on original fancybox 1.3.4
- Styles have been namespace
- Resources have been namespace
- Plugin has is now 'fancyboxPlus'
- Demo has been heavily reworked.
