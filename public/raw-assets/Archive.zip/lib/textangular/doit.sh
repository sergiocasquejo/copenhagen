./moveit.sh
cd ../Tracker2
gulp serve
cd textAngularJoelParke

