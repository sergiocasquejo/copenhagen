<a name="1.0.2"></a>

# 1.0.2 (21.06.2015)
- Add fancyboxable attribute directive.
- Made options an scoped attribute for the fancybox-plus element directive.
- Added angular-fancybox-plus demo. (also, Ported all examples of fancybox-plus demo into Angular.)
- Re-worked documentation.

<a name="1.0.0"></a>

# 1.0.0 (17.06.2015)
- build v1.0.1
- Initial commit, it includes bower repository settings.
