jQuery Easing Bower Package
=================

This is a Bower component for [jQuery easing](http://gsgd.co.uk/sandbox/jquery/easing/) plugin (v1.3).

# Installation

`bower install jquery.easing --save`

