<?php 

return array(
    'apiUsername' => env('PRIMESOFT_API_USERNAME'),
	'apiPassword' => env('PRIMESOFT_API_PASSWORD'),
	'apiKey' => env('PRIMESOFT_API_KEY'),
	'apiUrl' => env('PRIMESOFT_API_URL'),
    'apiPort1' => env('PRIESOFT_API_PORT_1'),
    'apiPort2' => env('PRIESOFT_API_PORT_2'),
    'apiReservationAgent' => env('PRIMESOFT_API_RESERVATION_AGENT'),
    'apiReservationName' => env('PRIMESOFT_API_RESERVATION_NAME'),
    'apiInfoSourceDesc' => env('PRIMESOFT_API_INFO_SOURCE_DESC'),
    'apiCompanyCode' => env('PRIMESOFT_API_COMPANY_CODE'),
    'apiPaymentType' => env('PRIMESOFT_API_PAYMENT_TYPE'),
    'apiMarketSegmentCode' => env('PRIMESOFT_API_MARKET_SEGMENT_CODE'),
);