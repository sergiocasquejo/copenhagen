<?php
Route::get('xxx/xxx', function() {
    $x = new Serge\Primesoft\Primesoft();
});