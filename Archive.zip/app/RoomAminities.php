<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoomAminities extends Model
{
    protected $table = 'rooms_aminities';
    public $timestamps = false;
}
