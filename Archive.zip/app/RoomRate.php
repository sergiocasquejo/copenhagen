<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoomRate extends Model
{
    protected $table = 'room_rates';
    public $timestamps = false;
}
