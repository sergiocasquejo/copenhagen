<?php $__env->startSection('content'); ?>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14">Hi <?php echo e($name); ?>,</p>
<h2 style="Margin-top: 30px;Margin-bottom: 0;font-style: normal;font-weight: normal;color: #44a8c7;font-size: 20px;line-height: 28px;text-align: left;">
          <font color="#0492bd"><center><?php echo e($pageHeading); ?></center></font></h2>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><center><?php echo e($message); ?></center></p>
<h2 style="Margin-top: 30px;Margin-bottom: 0;font-style: normal;font-weight: normal;color: #44a8c7;font-size: 20px;line-height: 28px;text-align: left;">
          <font color="#60666d">New Booking</font></h2>
<h3 style="Margin-top: 20px;Margin-bottom: 0;font-style: normal;font-weight: normal;color: #44a8c7;font-size: 18px;line-height: 20px;text-align: left;">
          <font color="#60666d">Details</font></h3>          
          <p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Reference Id</span> : <?php echo e($booking->refId); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Building</span> : Main</p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Check In</span> : <?php echo e(date('l F d Y', strtotime($booking->checkIn))); ?> <?php echo e($booking->checkInTime); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Check Out</span> : <?php echo e(date('l F d Y', strtotime($booking->checkOut))); ?> <?php echo e($booking->checkOutTime); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Guest</span> : <?php echo e($booking->noOfAdults); ?> Adult(s), <?php echo e((int)$booking->noOfChild); ?> Child</p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Rate:</span> :  <?php echo e($booking->nf($booking->roomRate, true)); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Nights</span> :  x <?php echo e($booking->noOfNights); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Rooms</span> : x <?php echo e($booking->noOfRooms); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Total</span> : <?php echo e($booking->nf($booking->totalAmount, true)); ?></b></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Booking Status</span> : <?php echo e($booking->status); ?></b></p>
<?php if($booking->lastPayment): ?>
<h3 style="Margin-top: 20px;Margin-bottom: 0;font-style: normal;font-weight: normal;color: #44a8c7;font-size: 20px;line-height: 28px;text-align: left;">
          <font color="#60666d">Payment Details</font></h3>  
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Payment Method</span> : <?php echo e($booking->lastPayment->method); ?></b></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Amount Paid</span> : <?php echo e($booking->nf($booking->lastPayment->totalAmount, true)); ?></b></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Payment Status</span> : <?php echo e($booking->lastPayment->status); ?></b></p>
<?php endif; ?>
<h3 style="Margin-top: 20px;Margin-bottom: 0;font-style: normal;font-weight: normal;color: #44a8c7;font-size: 20px;line-height: 28px;text-align: left;">
          <font color="#60666d">Customer Details</font></h3>          
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Name</span> : <?php echo e($booking->customer->salutation); ?>. <?php echo e($booking->customer->firstName); ?> <?php echo e($booking->customer->middleName); ?> <?php echo e($booking->customer->lastName); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Email</span> : <?php echo e($booking->customer->email); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Contact #</span> : <?php echo e($booking->customer->contact); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Address 1</span> : <?php echo e($booking->customer->address1); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Address 2</span> : <?php echo e($booking->customer->address2); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">State</span> : <?php echo e($booking->customer->state); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">City</span> : <?php echo e($booking->customer->city); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Zip Code</span> : <?php echo e($booking->customer->zipcode); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Country</span> : <?php echo e($booking->customer->countryCode); ?></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Special Notes</span> : <i><?php echo e($booking->specialInstructions); ?></i></p>
<p class="size-14" style="Margin-top: 10px;Margin-bottom: 0;font-size: 14px;line-height: 14px;text-align: left;" lang="x-size-14"><span style="display:inline-block;width:120px;">Billing Instruction</span> : <i><?php echo e($booking->billingInstructions); ?><i></p>
<p class="size-14" style="Margin-top: 30px;Margin-bottom: 0;font-size: 10px;line-height: 14px;text-align: left;" lang="x-size-14">Please do not reply to this email as it won't reach us. You have received this email because you have successfully booked with us.  </p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('emails.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>